package cs.uoi.gr.mye030.project;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import cs.uoi.gr.mye030.project.service.CountryService;
import cs.uoi.gr.mye030.project.service.TemperatureChangeService;

@SpringBootTest
public class TestService {
	
	@Autowired
	CountryService countryService;
	
	@Autowired
	TemperatureChangeService temperatureChangeService;
	
	@Test
	void testCountryServiceIsNotNull() {
		Assertions.assertNotNull(countryService);
	}
	
	@Test
	void testTemperatureChangeServiceIsNotNull() {
		Assertions.assertNotNull(temperatureChangeService);
	}
	
	@Test
	void testFindCountryIdByNameReturnsCountryName() {
		int countryID = countryService.findCountryIdByName("Greece");
		Assertions.assertNotNull(countryID);
		Assertions.assertEquals(85, countryID);
	}
	
	@Test
	void testFindAllYearsReturnsAllYears() {
		List<Integer> allYears = temperatureChangeService.findAllYears();
		Assertions.assertNotNull(allYears);
	}

}
