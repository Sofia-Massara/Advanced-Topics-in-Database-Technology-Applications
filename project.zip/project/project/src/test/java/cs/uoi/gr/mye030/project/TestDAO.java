package cs.uoi.gr.mye030.project;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import cs.uoi.gr.mye030.project.dao.ClimateDisastersDAO;
import cs.uoi.gr.mye030.project.dao.CountryDAO;
import cs.uoi.gr.mye030.project.dao.IndicatorDAO;
import cs.uoi.gr.mye030.project.model.Country;
import cs.uoi.gr.mye030.project.model.Indicator;

@SpringBootTest
public class TestDAO {
	
	@Autowired
	CountryDAO countryDAO;
	
	@Autowired
	IndicatorDAO indicatorDAO;
	
	@Autowired
	ClimateDisastersDAO climateDisastersDAO;
	
	@Test
	void testCountryDAOIsNotNull() {
		Assertions.assertNotNull(countryDAO);
	}
	
	@Test
	void testIndicatorDAOIsNotNull() {
		Assertions.assertNotNull(indicatorDAO);
	}
	
	@Test
	void testClimateDisastersDAOIsNotNull() {
		Assertions.assertNotNull(climateDisastersDAO);
	}
	
	@Test
	void testfindCountryrByIdReturnsIndicator() {
		Country storedCountry = countryDAO.findCountryById(85);
		Assertions.assertNotNull(storedCountry);
		Assertions.assertEquals(85, storedCountry.getCountryID());
		Assertions.assertEquals("Greece", storedCountry.getDisplayName());
		Assertions.assertEquals("Europe", storedCountry.getContinent());
	}
	
	@Test
	void testfindIndicatorByIdReturnsIndicator() {
		Indicator storedIndicator = indicatorDAO.findIndicatorById(1);
		Assertions.assertNotNull(storedIndicator);
		Assertions.assertEquals(1, storedIndicator.getIndicatorID());
		Assertions.assertEquals("Climate Altering Land Cover Index", storedIndicator.getIndicatorValue());
	}
	
	@Test
	void testFindAllYearsReturnsAllYears() {
		List<Integer> allYears = climateDisastersDAO.findAllYears();
		Assertions.assertNotNull(allYears);
	}

}
