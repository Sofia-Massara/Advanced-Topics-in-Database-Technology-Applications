package cs.uoi.gr.mye030.project;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import cs.uoi.gr.mye030.project.controller.MainController;

@SpringBootTest
@AutoConfigureMockMvc
public class TestMainController {
	
	@Autowired
    private WebApplicationContext context;
	
	@Autowired
	private MockMvc mockMvc;
	
	@Autowired
	MainController mainController;
	
	@BeforeEach
    public void setup() {
		mockMvc = MockMvcBuilders
          .webAppContextSetup(context)
          .build();
    }
	
	@Test
	void testMainControllerIsNotNull() {
		Assertions.assertNotNull(mainController);
	}
	
	@Test
	void testMockMvcIsNotNull() {
		Assertions.assertNotNull(mockMvc);
	}
	
	@Test 
	void testHomepageReturnsPage() throws Exception {
		mockMvc.perform(get("/"))
				.andExpect(status().isOk())
				.andExpect(view().name("HomeMenu"));		
	}
	
	@Test 
	void testCountryListReturnsPage() throws Exception {
		mockMvc.perform(get("/listCountries"))
				.andExpect(status().isOk())
				.andExpect(view().name("CountryList"));		
	}
	
	@Test 
	void testTemperatureChartPageReturnsPage() throws Exception {
		mockMvc.perform(get("/temperatureCharts"))
				.andExpect(status().isOk())
				.andExpect(view().name("ChartPage"));		
	}

}
