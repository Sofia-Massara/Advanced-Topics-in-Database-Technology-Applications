package cs.uoi.gr.mye030.project.dao;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import cs.uoi.gr.mye030.project.model.TemperatureChangeRecord;

@Repository
public interface TemperatureChangeDAO extends JpaRepository<TemperatureChangeRecord,Integer>{
	
	@Query("SELECT tcr FROM TemperatureChangeRecord tcr WHERE tcr.recordID = ?1")
    TemperatureChangeRecord findTemperatureRecordById(int id);
	
	@Query("SELECT Distinct(tcr.year) FROM TemperatureChangeRecord tcr")
    List<Integer> findAllYears();
    
	@Query("SELECT year,value FROM TemperatureChangeRecord tcr WHERE tcr.countryID = ?1")
	List<Object[]> findAnnualTemperatureChange(int countryID);
	
	@Query("SELECT AVG(tcr.value), SUM(cdr.value) FROM TemperatureChangeRecord tcr " +
	           "JOIN ClimateDisastersRecord cdr ON tcr.countryID = cdr.countryID AND tcr.year = cdr.year " +
	           "WHERE tcr.countryID = ?1 " +
	           "GROUP BY tcr.year, tcr.value")
	List<Object[]> findAnnualNumOfDisastersOnTempChange(int countryID);
	
	@Query("SELECT AVG(tcr.value), AVG(fcr.value) " +
		       "FROM TemperatureChangeRecord tcr " +
		       "JOIN ForestCarbonRecord fcr " +
		       "ON tcr.countryID = fcr.countryID " +
		       "AND tcr.year = fcr.year " +
		       "WHERE tcr.countryID = ?1 " +
		       "GROUP BY tcr.year")
	List<Object[]> findAverageForestCarbonOnTempChange(int countryID);
	

	@Query("SELECT tcr.year, AVG(tcr.value) FROM TemperatureChangeRecord tcr " +
	           "WHERE tcr.countryID = ?1 AND tcr.year BETWEEN ?2 AND ?3 " +
	           "GROUP BY tcr.year")
	List<Object[]> findAverageValueBetweenYearsByCountryId(int countryId, int year1, int year2);
	
}
