package cs.uoi.gr.mye030.project.service;

import java.util.List;

public interface ClimateDisastersService {
	
	List<Integer> findAllYears();
	
	List<Object[]> findSumOfDisastersPerYearByCountryID(int countryID);
    
	List<Object[]> findSumOfDisastersPerIndicatorByCountryID(int countryID);
    
    List<Object[]> findAvgValueByContinent();
    
    List<Object[]> findSumValueBetweenYearsByCountryId(int countryId, int year1, int year2);

}
