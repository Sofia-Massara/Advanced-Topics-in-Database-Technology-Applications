package cs.uoi.gr.mye030.project.service;

import java.util.List;

import cs.uoi.gr.mye030.project.model.LandCoverRecord;

public interface LandCoverService {
	
	List<LandCoverRecord> findByCountryID(int countryID);
	
	List<Integer> findAllYears();
    
    List<Object[]> findMeanValueByCountry(int countryID);

    List<Object[]> findMaxLandCoverByCountry(int countryID);
    
    List<Object[]> findMaxLandCoverByPopulationGroupedByContinent();
    
    List<Object[]> findAverageValueBetweenYearsByCountryId(int countryId, int year1, int year2);

}
