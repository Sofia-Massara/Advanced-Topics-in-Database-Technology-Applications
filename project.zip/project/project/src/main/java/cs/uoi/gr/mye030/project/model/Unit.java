package cs.uoi.gr.mye030.project.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="units")
public class Unit {
	
	@Id
	@Column(name="Unit_ID")
	private int unitID;
    
	@Column(name="Unit_Value")
	private String unitValue;
	
	public Unit() {
		
	}

	public Unit(int unitID, String unitValue) {
		super();
		this.unitID = unitID;
		this.unitValue = unitValue;
	}

	public int getUnitID() {
		return unitID;
	}

	public void setUnitID(int unitID) {
		this.unitID = unitID;
	}

	public String getUnitValue() {
		return unitValue;
	}

	public void setUnitValue(String unitValue) {
		this.unitValue = unitValue;
	}

	@Override
	public String toString() {
		return "Unit [unitID=" + unitID + ", unitValue=" + unitValue + "]";
	}
	
}