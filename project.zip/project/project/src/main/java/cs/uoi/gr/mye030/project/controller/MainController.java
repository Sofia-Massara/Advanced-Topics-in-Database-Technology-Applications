package cs.uoi.gr.mye030.project.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cs.uoi.gr.mye030.project.model.ChartForm;
import cs.uoi.gr.mye030.project.model.Country;
import cs.uoi.gr.mye030.project.model.Cts;
import cs.uoi.gr.mye030.project.model.Indicator;
import cs.uoi.gr.mye030.project.model.Source;
import cs.uoi.gr.mye030.project.model.Unit;
import cs.uoi.gr.mye030.project.service.ClimateDisastersService;
import cs.uoi.gr.mye030.project.service.CountryService;
import cs.uoi.gr.mye030.project.service.CtsService;
import cs.uoi.gr.mye030.project.service.ForestCarbonService;
import cs.uoi.gr.mye030.project.service.IndicatorService;
import cs.uoi.gr.mye030.project.service.LandCoverService;
import cs.uoi.gr.mye030.project.service.SourceService;
import cs.uoi.gr.mye030.project.service.TemperatureChangeService;
import cs.uoi.gr.mye030.project.service.UnitService;

@Controller
public class MainController {
	
	@Autowired
	private CountryService countryService;
	
	@Autowired
	private IndicatorService indicatorService;
	
	@Autowired
	private UnitService unitService;
	
	@Autowired
	private SourceService sourceService;
	
	@Autowired
	private CtsService ctsService;
	
	@Autowired
	private TemperatureChangeService temperatureChangeService;
	
	@Autowired
	private ClimateDisastersService climateDisastersService;
	
	@Autowired
	private ForestCarbonService forestCarbonService;
	
	@Autowired
	private LandCoverService landCoverService;
	
	@GetMapping("/homeMenu")
	public String getMenu(Model model) {
		return "HomeMenu";
	}
	
	@GetMapping("/listCountries")
	public String listCountries(Model model) {
		List<Country> countryList = countryService.findAllCountries();
		model.addAttribute("countries", countryList);
		return "CountryList";
	}
	
	@GetMapping("/listIndicators")
	public String listIndicators(Model model) {
		List<Indicator> indicatorList = indicatorService.findAll();
		model.addAttribute("indicators", indicatorList);
		return "IndicatorList";
	}
	
	@GetMapping("/listUnits")
	public String listUnits(Model model) {
		List<Unit> unitList = unitService.findAll();
		model.addAttribute("units", unitList);
		return "UnitList";
	}
	
	@GetMapping("/listSources")
	public String listSources(Model model) {
		List<Source> sourceList = sourceService.findAll();
		model.addAttribute("sources", sourceList);
		return "SourceList";
	}
	
	@GetMapping("/listCTSs")
	public String listCTSs(Model model) {
		List<Cts> ctsList = ctsService.findAll();
		model.addAttribute("ctss", ctsList);
		return "CtsList";
	}
	
	// TEMPERATURE CHANGE DATA PLOTTING
	@GetMapping("/temperatureCharts")
	public String getTemperatureChangesPage(Model model) {
		calculateAnnualTemperatureChange(model);
		calculateNumOfDisastersByTempChangePerYear(model);
		calculateAverageForestCarbonOnTempChange(model);
		model.addAttribute("title", "Temperature Change Charts Example");
		return "ChartPage";
	}
	
	// Calculate The Annual Temperature Change for 3 Countries
	private void calculateAnnualTemperatureChange(Model model) {
	    int[] countryIds = {85, 108, 166};    // Greece, Italy & Norway
	    List<Map<Integer, Float>> resultMapList = new ArrayList<>();
	    // Retrieve data for each country
	    for (int i = 0; i < countryIds.length; i++) {
	    	resultMapList.add(new HashMap<>());
	        int countryId = countryIds[i];
	        List<Object[]> objectList = temperatureChangeService.findAnnualTemperatureChange(countryId);
	        for (Object[] result : objectList) {
	            Integer year = (Integer) result[0];
	            Float averageValue = ((Number) result[1]).floatValue();
	            resultMapList.get(i).put(year, averageValue);
	        }
	    }
	    List<String> countryList = new ArrayList<>();
	    for(int i: countryIds) {
	    	countryList.add(countryService.findCountryNameById(i));
	    }
	    model.addAttribute("barLegendText", "Average Annual Temperature Change Values.");
	    model.addAttribute("barCountryList", countryList);
	    model.addAttribute("barDataList", resultMapList);
	}
	
	// Calculate the Num Of Disasters Based on Temp Change
	private void calculateNumOfDisastersByTempChangePerYear(Model model) {
		int[] countryIds = {85, 67, 128};
	    List<Map<Double, Integer>> resultMapList = new ArrayList<>();
	    // Retrieve data for each country
	    for (int i = 0; i < countryIds.length; i++) {
	    	resultMapList.add(new HashMap<>());
	        int countryId = countryIds[i];
	        List<Object[]> objectList = temperatureChangeService.findDisasterCountPerYearByCountry(countryId);
	        for (Object[] result : objectList) {
	        	Double tempValue = 0.0;
	        	if(result[0] != null) tempValue = (Double) result[0];
	            Long disasterSum = (Long) result[1];
	            Integer disasterSumInt = disasterSum != null ? disasterSum.intValue() : null;
	            resultMapList.get(i).put(tempValue, disasterSumInt);
	        }
	    }
	    List<String> countryList = new ArrayList<>();
	    for(int i: countryIds) {
	    	countryList.add(countryService.findCountryNameById(i));
	    }
	    model.addAttribute("scatterLegendText", "Total Number Of Disasters Based On Temperature Change Values.");
	    model.addAttribute("scatterCountryList", countryList);
	    model.addAttribute("scatterDataList", resultMapList);
	}
	
	// Calculate the Number Of Disasters Based on Temperature Change
	private void calculateAverageForestCarbonOnTempChange(Model model) {
		int[] countryIds = {85, 3, 12};
	    List<Map<Double, Double>> resultMapList = new ArrayList<>();
	    // Retrieve data for each country
	    for (int i = 0; i < countryIds.length; i++) {
	    	resultMapList.add(new HashMap<>());
	        int countryId = countryIds[i];
	        List<Object[]> objectList = temperatureChangeService.findAverageForestCarbonOnTempChange(countryId);
	        for (Object[] result : objectList) {
	        	Double tempValue = 0.0;
	        	if(result[0] != null) tempValue = (Double) result[0];
	        	Double carbonValue = 0.0;
	        	if(result[1] != null) carbonValue = (Double) result[1];
	        	
	            resultMapList.get(i).put(tempValue, carbonValue);
	        }
	    }
	    List<String> countryList = new ArrayList<>();
	    for(int i: countryIds) {
	    	countryList.add(countryService.findCountryNameById(i));
	    }
	    model.addAttribute("lineLegendText", "Average Forest Carbon Values Based On Temperature Change Values.");
	    model.addAttribute("lineCountryList", countryList);
	    model.addAttribute("lineDataList", resultMapList);
	}
	
	// CLIMATE DISASTERS DATA PLOTTING
	@GetMapping("/climateDisastersCharts")
	public String getClimateDisastersPage(Model model) {
		calculateSumOfDisastersPerYearByCountryID(model);
		calculateSumOfDisastersPerIndicatorByCountryID(model);
		calculateAvgValueForEachContinent(model);
		model.addAttribute("title", "Climate Disasters Charts Example");
		return "ChartPage";
	}
	
	// Calculate sum of climate disasters for each year
	private void calculateSumOfDisastersPerYearByCountryID(Model model) {
	    int[] countryIds = {85, 108, 166};    // Greece, Italy & Norway
	    List<Map<Integer, Integer>> resultMapList = new ArrayList<>();
	    // Retrieve data for each country
	    for (int i = 0; i < countryIds.length; i++) {
	        resultMapList.add(new HashMap<>());
	        int countryId = countryIds[i];
	        List<Object[]> objectList = climateDisastersService.findSumOfDisastersPerYearByCountryID(countryId);
	        for (Object[] result : objectList) {
	            Integer year = (Integer) result[0];
	            Long disasterSum = (Long) result[1];
	            Integer disasterSumInt = disasterSum != null ? disasterSum.intValue() : null;
	            resultMapList.get(i).put(year, disasterSumInt);
	        }
	    }
	    List<String> countryList = new ArrayList<>();
	    for(int i: countryIds) {
	    	countryList.add(countryService.findCountryNameById(i));
	    }
	    model.addAttribute("barLegendText", "Total Number Of Annual Disasters.");
	    model.addAttribute("barCountryList", countryList);
	    model.addAttribute("barDataList", resultMapList);
	}
	
	// Calculate sum of climate disasters for each year based on indicator
	private void calculateSumOfDisastersPerIndicatorByCountryID(Model model) {
		int[] countryIds = {87, 198, 154};
	    List<Map<Integer, Integer>> resultMapList = new ArrayList<>();
	    // Retrieve data for each country
	    for (int i = 0; i < countryIds.length; i++) {
	        resultMapList.add(new HashMap<>());
	        int countryId = countryIds[i];
	        List<Object[]> objectList = climateDisastersService.findSumOfDisastersPerIndicatorByCountryID(countryId);
	        for (Object[] result : objectList) {
	            Integer indicator = (Integer) result[0];
	            Long disasterSum = (Long) result[1];
	            Integer disasterSumInt = disasterSum != null ? disasterSum.intValue() : 0;
	            resultMapList.get(i).put(indicator, disasterSumInt);
	        }
	    }
	    List<String> countryList = new ArrayList<>();
	    for(int i: countryIds) {
	    	countryList.add(countryService.findCountryNameById(i));
	    }
	    model.addAttribute("scatterLegendText", "Total Number Of Disasters Grouped By Indicator Type.");
	    model.addAttribute("scatterCountryList", countryList);
	    model.addAttribute("scatterDataList", resultMapList);
	}
	
	// Calculate sum of climate disasters for each continent
	private void calculateAvgValueForEachContinent(Model model) {
	    List<Map<String, Double>> resultMapList = new ArrayList<>();
	    resultMapList.add(new HashMap<>());
	    List<Object[]> objectList = climateDisastersService.findAvgValueByContinent();
	    for (Object[] result : objectList) {
	        String continent = (String) result[0];
	        Double disasterAvg = (Double) result[1];
	        if(continent == null) continue;
	        if (disasterAvg == null) {
	            disasterAvg = 0.0;
	        }
	        resultMapList.get(0).put(continent, disasterAvg);
	    }
	    List<String> countryList = new ArrayList<>();
        countryList.add("Continents");
        model.addAttribute("lineLegendText", "Average Value Of Disasters Across All Countries Within Each Continent.");
        model.addAttribute("lineCountryList", countryList);
	    model.addAttribute("lineDataList", resultMapList);
	}

	// FOREST & CARBON DATA PLOTTING
	@GetMapping("/forestCarbonCharts")
	public String getForestCarbonPage(Model model) {
		calculateMeanAnnualForestCarbon(model);
		calculateAverageValuePerPopulationByContinent(model);
		calculateMaxForestCarbon(model);
		model.addAttribute("title", "Forest Carbon Charts Example");
		return "ChartPage";
	}
	
	// Calculate Mean Annual Forest Carbon for each country
	private void calculateMeanAnnualForestCarbon(Model model) {
		int[] countryIds = {253, 259, 268};
	    List<Map<Integer, Float>> resultMapList = new ArrayList<>();
	    // Retrieve data for each country
	    for (int i = 0; i < countryIds.length; i++) {
	        resultMapList.add(new HashMap<>());
	        int countryId = countryIds[i];
	        List<Object[]> objectList = forestCarbonService.findMeanValueByCountry(countryId);
	        for (Object[] result : objectList) {
	            Integer year = (Integer) result[0];
	            Float averageValue = null;
	            if(result[1]!=null) averageValue = ((Number) result[1]).floatValue();
	            resultMapList.get(i).put(year, averageValue);
	        }
	    }
	    List<String> countryList = new ArrayList<>();
	    for(int i: countryIds) {
	    	countryList.add(countryService.findCountryNameById(i));
	    }
	    model.addAttribute("barLegendText", "Average Value Of Annual Forest Carbon.");
	    model.addAttribute("barCountryList", countryList);
	    model.addAttribute("barDataList", resultMapList);
	}
	
	private void calculateMaxForestCarbon(Model model) {
		int[] countryIds = {265, 263, 264};    // Greece, Italy & Norway
	    List<Map<Integer, Float>> resultMapList = new ArrayList<>();
	    // Retrieve data for each country
	    for (int i = 0; i < countryIds.length; i++) {
	        resultMapList.add(new HashMap<>());
	        int countryId = countryIds[i];
	        List<Object[]> objectList = forestCarbonService.findMaxCarbonByCountry(countryId);
	        for (Object[] result : objectList) {
	        	Integer year = (Integer) result[0];
	            Float averageValue = null;
	            if(result[1]!=null) averageValue = ((Number) result[1]).floatValue();
	            resultMapList.get(i).put(year, averageValue);
	        }
	    }
	    List<String> countryList = new ArrayList<>();
	    for(int i: countryIds) {
	    	countryList.add(countryService.findCountryNameById(i));
	    }
	    model.addAttribute("scatterLegendText", "Maximum Value of Forest Carbon.");
	    model.addAttribute("scatterCountryList", countryList);
	    model.addAttribute("scatterDataList", resultMapList);
	}
	
	// Calculate Mean Annual Forest Carbon per population for each continent
	private void calculateAverageValuePerPopulationByContinent(Model model) {
	    List<Map<String, Double>> resultMapList = new ArrayList<>();
        resultMapList.add(new HashMap<>());
        List<Object[]> objectList = forestCarbonService.findAverageValueByContinent();
        for (Object[] result : objectList) {
        	String continent = (String) result[0];
 	        Double disasterAvg = (Double) result[1];
 	        if(continent == null) continue;
 	        if (disasterAvg == null) {
 	            disasterAvg = 0.0;
 	        }
 	        resultMapList.get(0).put(continent, disasterAvg);
        }
        List<String> countryList = new ArrayList<>();
        countryList.add("Continents");
        model.addAttribute("lineLegendText", "Average Value Of Forest Carbon Compared To The Population Of Each Country Within Each Continent.");
        model.addAttribute("lineCountryList", countryList);
	    model.addAttribute("lineDataList", resultMapList);
	}
	
	// LAND COVER DATA PLOTTING
	@GetMapping("/landCoverCharts")
	public String getLandCoverAccountsPage(Model model) {
		calculateMeanAnnualLandCover(model);
		calculateMaxLandCover(model);
		calculateMaxLandCoverByPopulationGroupedByContinent(model);
		model.addAttribute("title", "Land Cover Accounts Charts Example");
		return "ChartPage";
	}
	
	// 
	private void calculateMeanAnnualLandCover(Model model) {
		int[] countryIds = {70, 100, 136};
	    List<Map<Integer, Float>> resultMapList = new ArrayList<>();
	    // Retrieve data for each country
	    for (int i = 0; i < countryIds.length; i++) {
	        resultMapList.add(new HashMap<>());
	        int countryId = countryIds[i];
	        List<Object[]> objectList = landCoverService.findMeanValueByCountry(countryId);
	        for (Object[] result : objectList) {
	            Integer year = (Integer) result[0];
	            Float averageValue = null;
	            if(result[1]!=null) averageValue = ((Number) result[1]).floatValue();
	            resultMapList.get(i).put(year, averageValue);
	        }
	    }
	    List<String> countryList = new ArrayList<>();
	    for(int i: countryIds) {
	    	countryList.add(countryService.findCountryNameById(i));
	    }
	    model.addAttribute("barLegendText", "Average Annual Value Of Land Cover Accounts.");
	    model.addAttribute("barCountryList", countryList);
	    model.addAttribute("barDataList", resultMapList);
	}
	
	// Calculate the Highest Temp Change for each country for each year
	private void calculateMaxLandCover(Model model) {
		int[] countryIds = {3, 50, 206};
	    List<Map<Integer, Float>> resultMapList = new ArrayList<>();
	    // Retrieve data for each country
	    for (int i = 0; i < countryIds.length; i++) {
	        resultMapList.add(new HashMap<>());
	        int countryId = countryIds[i];
	        List<Object[]> objectList = landCoverService.findMaxLandCoverByCountry(countryId);
	        for (Object[] result : objectList) {
	        	Integer year = (Integer) result[0];
	            Float averageValue = null;
	            if(result[1]!=null) averageValue = ((Number) result[1]).floatValue();
	            resultMapList.get(i).put(year, averageValue);
	        }
	    }
	    List<String> countryList = new ArrayList<>();
	    for(int i: countryIds) {
	    	countryList.add(countryService.findCountryNameById(i));
	    }
	    model.addAttribute("scatterLegendText", "Maximum Value Of Land Cover Accounts.");
	    model.addAttribute("scatterCountryList", countryList);
	    model.addAttribute("scatterDataList", resultMapList);
	}
	
	// Calculate Mean Annual Forest Carbon per population for each continent
	private void calculateMaxLandCoverByPopulationGroupedByContinent(Model model) {
	    List<Map<String, Double>> resultMapList = new ArrayList<>();
        resultMapList.add(new HashMap<>());
        List<Object[]> objectList = forestCarbonService.findAverageValueByContinent();
        for (Object[] result : objectList) {
        	String continent = (String) result[0];
 	        Double landAvg = (Double) result[1];
 	        if(continent == null) continue;
 	        if (landAvg == null) {
 	        	landAvg = 0.0;
 	        }
 	        resultMapList.get(0).put(continent, landAvg);
        }
        List<String> countryList = new ArrayList<>();
        countryList.add("Continents");
        model.addAttribute("lineLegendText", "Maximum Value Of Land Cover Accounts Compared To The Population Of Each Country Within Each Continent.");
        model.addAttribute("lineCountryList", countryList);
	    model.addAttribute("lineDataList", resultMapList);
	}

	// CUSTOM USER CHARTS
	@GetMapping("/customUserCharts")
	public String getCustomUserPage(Model model) {
		initializeForm(model);
		return "CustomUserChart";
	}
	
	@GetMapping("/fetchYears")
    @ResponseBody
	public List<Integer> getYearsForDataTypes(@RequestParam("datatype") String dataType) {
		List<Integer> yearList = new ArrayList<Integer>();
		switch (dataType) {
		    case "Temperature Change Data":
		        yearList = temperatureChangeService.findAllYears();
		        break;
		    case "Climate Disasters Data":
		    	yearList = climateDisastersService.findAllYears();
		    	break;
		    case "Forest & Carbon Data":
		    	yearList = forestCarbonService.findAllYears();
		    	break;
		    case "Land Cover Accounts Data":
		    	yearList = landCoverService.findAllYears();
		    	break;
		}
		return yearList;
	}
	
	private void initializeForm(Model model) {
        List<String> countryList = countryService.findAllCountryNames();
        List<String> dataList = new ArrayList<>();
        List<String> chartList = new ArrayList<>();
        
        dataList.add("Temperature Change Data");
        dataList.add("Climate Disasters Data");
        dataList.add("Forest & Carbon Data");
        dataList.add("Land Cover Accounts Data");

        chartList.add("Bar Chart");
        chartList.add("Scatter Chart");
        chartList.add("Line Chart");

        model.addAttribute("countries", countryList);
        model.addAttribute("datatypes", dataList);
        model.addAttribute("charttypes", chartList);
        model.addAttribute("years", new ArrayList<>());
        model.addAttribute("chartForm", new ChartForm());
    }
	
	@PostMapping("/submit")
	public String submitForm(@ModelAttribute ChartForm chartForm, Model model) {
	    // Add the chart form object to the model
	    model.addAttribute("chartForm", chartForm);

	    // Process the form data only if all necessary fields are provided
	    if (chartForm.getChartType() != null && !chartForm.getYears().isEmpty() && chartForm.getYears() != null && chartForm.getCountry() != null && !chartForm.getCountry().isEmpty()) {
	        // Initialize the result map list
	        List<Map<Integer, Number>> resultMapList = new ArrayList<>();

	        // Retrieve the country IDs based on the selected country names
	        List<Integer> countryIDs = new ArrayList<>();
	        for (String countryName : chartForm.getCountry()) {
	            Integer countryId = countryService.findCountryIdByName(countryName);
	            if (countryId != null) {
	                countryIDs.add(countryId);
	            }
	        }

	        // Determine the range of years
	        Integer year1 = Collections.min(chartForm.getYears());
	        Integer year2 = Collections.max(chartForm.getYears());

	        // Process data based on the selected chart type
	        switch (chartForm.getDataType()) {
	            case "Temperature Change Data":
	                for (Integer countryId : countryIDs) {
	                    Map<Integer, Number> countryData = new HashMap<>();
	                    List<Object[]> objectList = temperatureChangeService.findAverageValueBetweenYearsByCountryId(countryId, year1, year2);
	                    for (Object[] result : objectList) {
	                        Integer year = (Integer) result[0];
	                        Number averageValue = (Number) result[1];
	                        countryData.put(year, averageValue);
	                    }
	                    resultMapList.add(countryData);
	                }
	                model.addAttribute("legendText", "Average Value of Temperature Change For the Years: "+year1+"-"+year2);
	                break;
	            case "Climate Disasters Data":
	            	for (Integer countryId : countryIDs) {
	                    Map<Integer, Number> countryData = new HashMap<>();
	                    List<Object[]> objectList = climateDisastersService.findSumValueBetweenYearsByCountryId(countryId, year1, year2);
	                    for (Object[] result : objectList) {
	                        Integer year = (Integer) result[0];
	                        Long disasterSum = (Long) result[1];
				            Integer disasterSumInt = disasterSum != null ? disasterSum.intValue() : 0;
	                        countryData.put(year, disasterSumInt);
	                    }
	                    resultMapList.add(countryData);
	                }
	            	model.addAttribute("legendText", "Total Number of Climate Disasters For the Years: "+year1+"-"+year2);
	                break;
	            case "Forest & Carbon Data":
	            	for (Integer countryId : countryIDs) {
	                    Map<Integer, Number> countryData = new HashMap<>();
	                    List<Object[]> objectList = forestCarbonService.findAverageValueBetweenYearsByCountryId(countryId, year1, year2);
				    	for (Object[] result : objectList) {
				            Integer year = (Integer) result[0];
				            Float averageValue = null;
				            if(result[1]!=null) averageValue = ((Number) result[1]).floatValue();
				            countryData.put(year, averageValue);
	                    }
	                    resultMapList.add(countryData);
	            	}
	            	model.addAttribute("legendText", "Average Value of Forest & Carbon Data For the Years: "+year1+"-"+year2);
			        break;
	            case "Land Cover Accounts Data":
	            	for (Integer countryId : countryIDs) {
	                    Map<Integer, Number> countryData = new HashMap<>();
	                    List<Object[]> objectList = landCoverService.findAverageValueBetweenYearsByCountryId(countryId, year1, year2);
				    	for (Object[] result : objectList) {
				            Integer year = (Integer) result[0];
				            Float averageValue = null;
				            if(result[1]!=null) averageValue = ((Number) result[1]).floatValue();
				            countryData.put(year, averageValue);
	                    }
	                    resultMapList.add(countryData);
	            	}
	            	model.addAttribute("legendText", "Average Value of Land Cover Accounts For the Years: "+year1+"-"+year2);
			        break;
	        }
	        // Add the result map list and country list to the model based on the chart type
	        switch (chartForm.getChartType()) {
	            case "Bar Chart":
	                model.addAttribute("barDataList", resultMapList);
	                break;
	            case "Scatter Chart":
	                model.addAttribute("scatterDataList", resultMapList);
	                break;
	            case "Line Chart":
	                model.addAttribute("lineDataList", resultMapList);
	                break;
	            default:
	                // Handle invalid chart type
	                break;
	        }
	        // Add countries
	        model.addAttribute("countryList", chartForm.getCountry());
	    }

	    // Initialize the form with default values
	    initializeForm(model);

	    // Return the view name
	    return "CustomUserChart";
	}
	
}
