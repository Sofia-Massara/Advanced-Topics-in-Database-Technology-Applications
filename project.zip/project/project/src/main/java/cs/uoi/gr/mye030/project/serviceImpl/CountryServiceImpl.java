package cs.uoi.gr.mye030.project.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cs.uoi.gr.mye030.project.dao.CountryDAO;
import cs.uoi.gr.mye030.project.model.Country;
import cs.uoi.gr.mye030.project.service.CountryService;

@Service
public class CountryServiceImpl implements CountryService {
	
	@Autowired
	private CountryDAO countryDAO;

	@Override
	public Country findById(int Id) {
		return countryDAO.findCountryById(Id);
	}

	@Override
	public List<Country> findAllCountries() {
		return countryDAO.findAllCountries();
	}

	@Override
	public List<String> findAllCountryNames() {
		return countryDAO.findAllCountryNames();
	}

	@Override
	public int findCountryIdByName(String displayName) {
		return countryDAO.findCountryIdByName(displayName);
	}

	@Override
	public String findCountryNameById(int countryId) {
		return countryDAO.findCountryNameById(countryId);
	}

}
