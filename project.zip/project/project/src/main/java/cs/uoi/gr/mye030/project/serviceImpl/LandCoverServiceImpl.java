package cs.uoi.gr.mye030.project.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cs.uoi.gr.mye030.project.dao.LandCoverDAO;
import cs.uoi.gr.mye030.project.model.LandCoverRecord;
import cs.uoi.gr.mye030.project.service.LandCoverService;

@Service
public class LandCoverServiceImpl implements LandCoverService {
	
	@Autowired
	private LandCoverDAO landCoverDAO;

	@Override
	public List<LandCoverRecord> findByCountryID(int countryID) {
		return landCoverDAO.findByCountryID(countryID);
	}
	
	@Override
	public List<Integer> findAllYears() {
		return landCoverDAO.findAllYears();
	}

	@Override
	public List<Object[]> findMeanValueByCountry(int countryID) {
		return landCoverDAO.findMeanValueByCountry(countryID);
	}

	@Override
	public List<Object[]> findMaxLandCoverByCountry(int countryID) {
		return landCoverDAO.findMaxLandCoverByCountry(countryID);
	}

	@Override
	public List<Object[]> findMaxLandCoverByPopulationGroupedByContinent() {
		return landCoverDAO.findMaxLandCoverByPopulationGroupedByContinent();
	}

	@Override
	public List<Object[]> findAverageValueBetweenYearsByCountryId(int countryId, int year1, int year2) {
		return landCoverDAO.findAverageValueBetweenYearsByCountryId(countryId, year1, year2);
	}

}
