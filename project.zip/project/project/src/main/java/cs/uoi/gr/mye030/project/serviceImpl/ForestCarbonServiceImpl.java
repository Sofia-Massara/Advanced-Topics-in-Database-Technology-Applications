package cs.uoi.gr.mye030.project.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cs.uoi.gr.mye030.project.dao.ForestCarbonDAO;
import cs.uoi.gr.mye030.project.model.ForestCarbonRecord;
import cs.uoi.gr.mye030.project.service.ForestCarbonService;

@Service
public class ForestCarbonServiceImpl implements ForestCarbonService {
	
	@Autowired
	private ForestCarbonDAO forestCarbonDAO;

	@Override
	public List<ForestCarbonRecord> findByCountryID(int countryID) {
		return forestCarbonDAO.findByCountryID(countryID);
	}
	
	@Override
	public List<Integer> findAllYears() {
		return forestCarbonDAO.findAllYears();
	}

	@Override
	public List<Object[]> findMeanValueByCountry(int countryID) {
		return forestCarbonDAO.findMeanValueByCountry(countryID);
	}

	@Override
	public List<Object[]> findMaxCarbonByCountry(int countryID) {
		return forestCarbonDAO.findMaxCarbonByCountry(countryID);
	}

	@Override
	public List<Object[]> findAverageValueByContinent() {
		return forestCarbonDAO.findAvgForestCarbonByPopulationGroupedByContinent();
	}

	@Override
	public List<Object[]> findAverageValueBetweenYearsByCountryId(int countryId, int year1, int year2) {
		return forestCarbonDAO.findAverageValueBetweenYearsByCountryId(countryId, year1, year2);
	}

}
