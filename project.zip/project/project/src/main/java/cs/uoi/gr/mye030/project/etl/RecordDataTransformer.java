package cs.uoi.gr.mye030.project.etl;

import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

public class RecordDataTransformer {
	
	public static void main(String[] args) {
		System.out.println("Transforming record data...\n");
		transformRecordFile("src/main/resources/data/Annual_Surface_Temperature_Change.csv", "src/main/resources/tf_data/Tf_Temperature_Data.csv");
		transformRecordFile("src/main/resources/data/Climate-related_Disasters_Frequency.csv", "src/main/resources/tf_data/Tf_Climate_Disasters_Data.csv");
		transformRecordFile("src/main/resources/data/Forest_and_Carbon.csv", "src/main/resources/tf_data/Tf_Forest_Carbon_Data.csv");
		transformRecordFile("src/main/resources/data/Land_Cover_Accounts.csv", "src/main/resources/tf_data/Tf_Land_Cover_Data.csv");
		System.out.println("Record data transformation complete!");
	}
	
	private static void transformRecordFile(String inputFile, String outputFile) {
	    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mye030_db", "root", "root")) {
	    	CSVReader reader = new CSVReader(new FileReader(inputFile));
	        BufferedWriter bw = new BufferedWriter(new FileWriter(outputFile));

	        // Skip header line
	        String[] header = null;
			try {
				header = reader.readNext();
			} catch (CsvValidationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	        // Set header and starting index for year
			int startIndex = 0;
	        String header1 = "RecordID,CountryID,IndicatorID,UnitID,SourceID,CTS_ID,Climate_Influence,Year,Value\n";
	        String header2 = "RecordID,CountryID,IndicatorID,UnitID,SourceID,CTS_ID,Year,Value\n";
	        if(header[10].equals("Climate_Influence")) {
	        	bw.write(header1);
	        	startIndex = 11;
	        }
	        else {
	        	bw.write(header2);
	        	startIndex = 10;
	        }
	        String[] columns;
	        int recordID = 1;
	        while ((columns = reader.readNext()) != null) {
		        String data = "";
	            String iso3 = columns[3];	// ISO_3
	            String indicator = columns[4]; // Indicator
	            String unit = columns[5]; // Unit
	            String source = columns[6]; // Source
	            String ctsCode = columns[7]; // CTS_Code
	            String ctsName = columns[8]; // CTS_Name
	            String ctsFullDescriptor = columns[9]; // CTS_Full_Descriptor
	            String climateInfluence = "";
	            // Get IDs from database
                int countryID = getCountryID(conn, iso3);
                int indicatorID = getIndicatorID(conn, indicator);
                int unitID = getUnitID(conn, unit);
                int sourceID = getSourceID(conn, source);
                int ctsID = getCtsID(conn, ctsCode, ctsName, ctsFullDescriptor);
	            for (int i = startIndex; i < columns.length; i++) {
	            	if(!header[10].equals("Climate_Influence")) {
		            	data = recordID + "," + countryID  + ","  + indicatorID  + "," + unitID + "," + sourceID + "," + ctsID;
		            }
		            else {
		            	climateInfluence = columns[10];	// Climate Influence
		            	data = recordID + "," + countryID  + ","  + indicatorID  + "," + unitID + "," + sourceID + "," + ctsID + "," + "\"" + climateInfluence + "\"";
		            }
	                String year = header[i].substring(1); // Year
	                String value = columns[i]; // Value
	                data += "," + year + "," + value + "\n";
	                bw.write(data);	// Write transformed data to the output file
	                recordID++;	// Increment recordID (primary key) for each unique record
	            }
	        }
	        reader.close();
	        bw.close();
	        System.out.println("Data transformation for " + inputFile + " completed successfully.\nTransformed data exported to " + outputFile + "\n");
	    } catch (IOException | SQLException e) {
	        e.printStackTrace();
	    } catch (CsvValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Find Country_ID by checking the ISO_3
    private static int getCountryID(Connection conn, String iso3) throws SQLException {
        String query = "SELECT Country_ID FROM countries WHERE ISO_3 = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, iso3);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("Country_ID");
                }
            }
        }
        System.out.println("Country with ISO_3 " + iso3 + " was not found!");
        return -1; // Country not found
    }
    
    // Find Indicator_ID by checking the Value
    private static int getIndicatorID(Connection conn, String indicator) {
        String query = "SELECT Indicator_ID FROM indicators WHERE Indicator_Value = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, indicator);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("Indicator_ID"); // Indicator found
                } else {
                    System.err.println("Indicator with Value '" + indicator + "' was not found!");
                    return -1; // Indicator not found
                }
            }
        } catch (SQLException e) {
            System.err.println("Error occurred while fetching Indicator_ID for indicator '" + indicator + "': " + e.getMessage());
            return -1; // Indicator not found due to SQL exception
        }
    }

    // Find Unit_ID by checking the Value
    private static int getUnitID(Connection conn, String unit) {
        String query = "SELECT Unit_ID FROM units WHERE Unit_Value = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, unit);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("Unit_ID"); // Unit found
                } else {
                    System.err.println("Unit with Value '" + unit + "' was not found!");
                    return -1; // Unit not found
                }
            }
        } catch (SQLException e) {
            System.err.println("Error occurred while fetching Unit_ID for unit '" + unit + "': " + e.getMessage());
            return -1; // Unit not found due to SQL exception
        }
    }

    // Find Source_ID by checking the Value
    private static int getSourceID(Connection conn, String source) {
        String query = "SELECT Source_ID FROM sources WHERE Source_Value = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, source);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("Source_ID");	// Source found
                } else {
                    System.out.println("Source with Value '" + source + "' was not found!");
                    return -1; // Source not found
                }
            }
        } catch (SQLException e) {
            System.err.println("Error occurred while fetching Source_ID for source '" + source + "': " + e.getMessage());
            return -1; // Source not found due to SQL exception
        }
    }

    // Find CTS_ID by checking all 3 Values
    private static int getCtsID(Connection conn, String ctsCode, String ctsName, String ctsFullDescriptor) {
        String query = "SELECT CTS_ID FROM ctss WHERE CTS_Code = ? AND CTS_Name = ? AND CTS_Full_Descriptor = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, ctsCode);
            pstmt.setString(2, ctsName);
            pstmt.setString(3, ctsFullDescriptor);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("CTS_ID");	// CTS found
                } else {
                    System.out.println("CTS was not found!");
                    return 17; // CTS not found
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return -1; // CTS not found due to SQL exception
        }
    }

}
