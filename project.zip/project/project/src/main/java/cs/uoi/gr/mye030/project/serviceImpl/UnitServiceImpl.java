package cs.uoi.gr.mye030.project.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cs.uoi.gr.mye030.project.dao.UnitDAO;
import cs.uoi.gr.mye030.project.model.Unit;
import cs.uoi.gr.mye030.project.service.UnitService;

@Service
public class UnitServiceImpl implements UnitService{
	
	@Autowired
	private UnitDAO unitDAO;

	@Override
	public Unit findById(int id) {
		return unitDAO.findUnitById(id);
	}

	@Override
	public List<Unit> findAll() {
		return unitDAO.findAllUnits();
	}

}
