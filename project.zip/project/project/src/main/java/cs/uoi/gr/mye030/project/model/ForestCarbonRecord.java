package cs.uoi.gr.mye030.project.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="forest_carbon_records")
public class ForestCarbonRecord {
	
	@Id
	@Column(name="Record_ID")
	private int recordID; 	// Primary Key
	
	@Column(name="Country_ID")
	private int countryID;
	
	@Column(name="Indicator_ID")
	private int indicatorID;
	
	@Column(name="Unit_ID")
	private int unitID;
	
	@Column(name="Source_ID")
	private int sourceID;
	
	@Column(name="CTS_Code")
	private int CTS_ID;
	
	@Column(name="Year")
	private int year;
	
	@Column(name="Value")
	private Float value;	// Use wrapper class for Null values in db
	
	public ForestCarbonRecord() {
		
	}

	public ForestCarbonRecord(int recordID, int countryID, int indicatorID, int unitID, int sourceID, int cTS_ID,
			int year, Float value) {
		super();
		this.recordID = recordID;
		this.countryID = countryID;
		this.indicatorID = indicatorID;
		this.unitID = unitID;
		this.sourceID = sourceID;
		CTS_ID = cTS_ID;
		this.year = year;
		this.value = value;
	}

	public int getRecordID() {
		return recordID;
	}

	public void setRecordID(int recordID) {
		this.recordID = recordID;
	}

	public int getCountryID() {
		return countryID;
	}

	public void setCountryID(int countryID) {
		this.countryID = countryID;
	}

	public int getIndicatorID() {
		return indicatorID;
	}

	public void setIndicatorID(int indicatorID) {
		this.indicatorID = indicatorID;
	}

	public int getUnitID() {
		return unitID;
	}

	public void setUnitID(int unitID) {
		this.unitID = unitID;
	}

	public int getSourceID() {
		return sourceID;
	}

	public void setSourceID(int sourceID) {
		this.sourceID = sourceID;
	}

	public int getCTS_ID() {
		return CTS_ID;
	}

	public void setCTS_ID(int cTS_ID) {
		CTS_ID = cTS_ID;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public Float getValue() {
		return value;
	}

	public void setValue(Float value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "ForestCarbonRecord [recordID=" + recordID + ", countryID=" + countryID + ", indicatorID=" + indicatorID
				+ ", unitID=" + unitID + ", sourceID=" + sourceID + ", CTS_ID=" + CTS_ID + ", year=" + year + ", value="
				+ value + "]";
	}
	
}
