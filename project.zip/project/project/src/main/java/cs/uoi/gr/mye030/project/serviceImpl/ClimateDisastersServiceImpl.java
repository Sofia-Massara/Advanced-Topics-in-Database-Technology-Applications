package cs.uoi.gr.mye030.project.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cs.uoi.gr.mye030.project.dao.ClimateDisastersDAO;
import cs.uoi.gr.mye030.project.service.ClimateDisastersService;

@Service
public class ClimateDisastersServiceImpl implements ClimateDisastersService {
	
	@Autowired
	private ClimateDisastersDAO climateDisastersDAO;
	
	@Override
	public List<Integer> findAllYears() {
		return climateDisastersDAO.findAllYears();
	}

	@Override
	public List<Object[]> findSumOfDisastersPerYearByCountryID(int countryID) {
		return climateDisastersDAO.findSumOfDisastersPerYearByCountryID(countryID);
	}

	@Override
	public List<Object[]> findSumOfDisastersPerIndicatorByCountryID(int countryID) {
		return climateDisastersDAO.findSumOfDisastersPerIndicatorByCountryID(countryID);
	}

	@Override
	public List<Object[]> findAvgValueByContinent() {
		return climateDisastersDAO.findAverageValueByContinent();
	}

	@Override
	public List<Object[]> findSumValueBetweenYearsByCountryId(int countryId, int year1, int year2) {
		return climateDisastersDAO.findSumValueBetweenYearsByCountryId(countryId, year1, year2);
	}

}
