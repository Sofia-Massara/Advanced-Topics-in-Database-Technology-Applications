package cs.uoi.gr.mye030.project.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import cs.uoi.gr.mye030.project.model.ClimateDisastersRecord;

@Repository
public interface ClimateDisastersDAO extends JpaRepository<ClimateDisastersRecord,Integer> {
	
    // Find all climate disasters records for a specific country for each year
    @Query("SELECT year, SUM(cdr.value) FROM ClimateDisastersRecord cdr WHERE cdr.countryID = ?1 GROUP BY Year")
    List<Object[]> findSumOfDisastersPerYearByCountryID(int countryID);
    
    @Query("SELECT Distinct(cdr.year) FROM ClimateDisastersRecord cdr")
    List<Integer> findAllYears();
    
    // Find all climate disasters records for a specific country based on the indicator
    @Query("SELECT i.indicatorID, SUM(cdr.value)" +
    	       "FROM ClimateDisastersRecord cdr " +
    	       "JOIN Indicator i ON cdr.indicatorID = i.indicatorID " +
    	       "WHERE cdr.countryID = ?1 " +
    	       "GROUP BY i.indicatorID, cdr.countryID")
    List<Object[]> findSumOfDisastersPerIndicatorByCountryID(int countryID);
    
    // Find the average climate disasters value for all countries based on the continent
    @Query("SELECT c.continent, AVG(cdr.value) " +
    	       "FROM ClimateDisastersRecord cdr " +
    	       "JOIN Country c ON cdr.countryID = c.countryID " +
    	       "GROUP BY c.continent")
    List<Object[]> findAverageValueByContinent();
    
    @Query("SELECT cdr.year, SUM(cdr.value) FROM ClimateDisastersRecord cdr " +
	           "WHERE cdr.countryID = ?1 AND cdr.year BETWEEN ?2 AND ?3 " +
	           "GROUP BY cdr.year")
	List<Object[]> findSumValueBetweenYearsByCountryId(int countryId, int year1, int year2);


}
