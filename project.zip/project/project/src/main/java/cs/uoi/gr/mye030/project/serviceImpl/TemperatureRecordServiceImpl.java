package cs.uoi.gr.mye030.project.serviceImpl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cs.uoi.gr.mye030.project.dao.TemperatureChangeDAO;
import cs.uoi.gr.mye030.project.model.TemperatureChangeRecord;
import cs.uoi.gr.mye030.project.service.TemperatureChangeService;

@Service
public class TemperatureRecordServiceImpl implements TemperatureChangeService{
	
	@Autowired
	private TemperatureChangeDAO temperatureChangeDAO;

	@Override
	public TemperatureChangeRecord findRecordById(int id) {
		return temperatureChangeDAO.findTemperatureRecordById(id);
	}
	
	@Override
	public List<Integer> findAllYears() {
		return temperatureChangeDAO.findAllYears();
	}

	@Override
	public List<Object[]> findAnnualTemperatureChange(int countryID) {
		return temperatureChangeDAO.findAnnualTemperatureChange(countryID);
	}

	@Override
	public List<Object[]> findDisasterCountPerYearByCountry(int countryID) {
		return temperatureChangeDAO.findAnnualNumOfDisastersOnTempChange(countryID);
	}

	@Override
	public List<Object[]> findAverageForestCarbonOnTempChange(int countryID) {
		return temperatureChangeDAO.findAverageForestCarbonOnTempChange(countryID);
	}

	@Override
	public List<Object[]> findAverageValueBetweenYearsByCountryId(int countryId, int year1, int year2) {
		return temperatureChangeDAO.findAverageValueBetweenYearsByCountryId(countryId, year1, year2);
	}

}
