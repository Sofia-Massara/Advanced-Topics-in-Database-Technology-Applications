package cs.uoi.gr.mye030.project.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import cs.uoi.gr.mye030.project.model.LandCoverRecord;

@Repository
public interface LandCoverDAO extends JpaRepository<LandCoverRecord,Integer>{
	
    @Query("SELECT lcr FROM LandCoverRecord lcr WHERE lcr.countryID = ?1")
    List<LandCoverRecord> findByCountryID(int countryID);
    
    @Query("SELECT Distinct(lcr.year) FROM LandCoverRecord lcr")
    List<Integer> findAllYears();
    
    @Query("SELECT year, AVG(lcr.value) FROM LandCoverRecord lcr WHERE lcr.countryID = ?1 GROUP BY Year")
    List<Object[]> findMeanValueByCountry(int countryID);

    @Query("SELECT year, MAX(lcr.value) FROM LandCoverRecord lcr WHERE lcr.countryID = ?1 GROUP BY Year")
    List<Object[]> findMaxLandCoverByCountry(int countryID);
    
    // Calculate the maximum land cover value weighted by population for each country grouped by continent
    @Query("SELECT c.continent, MAX(lcr.value * c.population) / AVG(c.population) " +
           "FROM LandCoverRecord lcr " +
           "JOIN Country c ON lcr.countryID = c.countryID " +
           "GROUP BY c.continent, c.displayName")
    List<Object[]> findMaxLandCoverByPopulationGroupedByContinent();

    @Query("SELECT lcr.year, AVG(lcr.value) FROM LandCoverRecord lcr " +
	           "WHERE lcr.countryID = ?1 AND lcr.year BETWEEN ?2 AND ?3 " +
	           "GROUP BY lcr.year")
	List<Object[]> findAverageValueBetweenYearsByCountryId(int countryId, int year1, int year2);
	
}
