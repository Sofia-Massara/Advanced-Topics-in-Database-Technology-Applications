package cs.uoi.gr.mye030.project.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import cs.uoi.gr.mye030.project.model.Indicator;

@Repository
public interface IndicatorDAO extends JpaRepository<Indicator,Integer>{
	
	@Query("select i from Indicator i where i.indicatorID = ?1")
    public Indicator findIndicatorById(int id);
    
    @Query("select i from Indicator i")
    public List<Indicator> findAllIndicators();

}
