package cs.uoi.gr.mye030.project.etl;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import com.opencsv.CSVReader;

public class MissingCountriesFinder {

	// Class to keep the country data retrieved from the record files
    static class CountryData {
        private String name;
        private String ISO2;
        private String ISO3;

        public CountryData(String name, String ISO2, String ISO3) {
            this.name = name;
            this.ISO2 = ISO2;
            this.ISO3 = ISO3;
        }

        public String getName() {
            return name;
        }

        public String getISO2() {
            return ISO2;
        }

        public String getISO3() {
            return ISO3;
        }
        
		public String toString() {
			return "CountryData [name=" + name + ", ISO2=" + ISO2 + ", ISO3=" + ISO3 + "]";
		}
    }
    
    public void findMissingCountries() {
    	
    	String csvFilePaths[] = {"src/main/resources/data/Annual_Surface_Temperature_Change.csv",
    	                          "src/main/resources/data/Climate-related_Disasters_Frequency.csv",
    	                          "src/main/resources/data/Forest_and_Carbon.csv",
    	                          "src/main/resources/data/Land_Cover_Accounts.csv"};
    	
    	System.out.println("Adding missing countries...");
    	
    	try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mye030_db", "root", "root")) {
    		// Disable auto-commit to start a transaction
            connection.setAutoCommit(false);
    		for(String filePath: csvFilePaths) {
    			ArrayList<CountryData> missingCountries = openCSVAndCheckCountries(filePath);
    			insertMissingCountries(connection, missingCountries);
    			// Commit the transaction
    			connection.commit();
    		}
    		
    	} catch (SQLException e) {
            e.printStackTrace();
        }
    	
    	System.out.println("\nMissing country insertion complete!");
    	
    }
    
    // Method to check if a country exists in the database
    public static boolean countryExists(String countryName) {
        String sql = "SELECT COUNT(*) AS count FROM Countries WHERE ISO_3 = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mye030_db", "root", "root"); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, countryName);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt("count");
                    return count > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; // Country not found or error occurred
    }
    
    public static ArrayList<CountryData> openCSVAndCheckCountries(String csvFilePath) {
    	ArrayList<CountryData> missingCountryList = new ArrayList<CountryData>();
    	ArrayList<CountryData> uniqueList = new ArrayList<>();
    	try (CSVReader reader = new CSVReader(new FileReader(csvFilePath))) {
            reader.readNext(); // Read the header line
            String[] line;
            while ((line = reader.readNext()) != null) {
            	String name = line[1].trim();
                String iso2 = line[2];
                String iso3 = line[3];
                // Remove leading quote if present
                name = name.replaceAll("^\"|\"$", "");
                // Check if the country exists in the database
                boolean exists = countryExists(iso3);
                if (!exists) {
                	CountryData missingCountry = new CountryData(name, iso2, iso3);
                	// System.out.println(missingCountry);
                	missingCountryList.add(missingCountry);
                }
            }
            Set<String> uniqueNames = new HashSet<>();
            for (CountryData obj : missingCountryList) {
                if (uniqueNames.add(obj.getName())) {
                    uniqueList.add(obj);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
		return uniqueList;
    }
    
    
    private static void insertMissingCountries(Connection conn, ArrayList<CountryData> missingCountries) throws SQLException {
        String insertSql = "INSERT INTO Countries (Display_Name, Official_Name, ISO_2, ISO_3) VALUES (?, ?, ?, ?)";
        String name = "";
        try (PreparedStatement pstmt = conn.prepareStatement(insertSql)) {
        	for(CountryData country: missingCountries) {
        		name = country.getName();
        		pstmt.setString(1, country.getName());
        		pstmt.setString(2, country.getName());
                pstmt.setString(3, country.getISO2());
                pstmt.setString(4, country.getISO3());
                pstmt.executeUpdate();
                System.out.println("Inserted country: " + name);
        	}
        }
    }
    
}
