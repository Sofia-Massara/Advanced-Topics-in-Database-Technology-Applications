package cs.uoi.gr.mye030.project.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cs.uoi.gr.mye030.project.dao.SourceDAO;
import cs.uoi.gr.mye030.project.model.Source;
import cs.uoi.gr.mye030.project.service.SourceService;

@Service
public class SourceServiceImpl implements SourceService {
	
	@Autowired
	private SourceDAO sourceDAO;

	@Override
	public Source findById(int id) {
		return sourceDAO.findSourceById(id);
	}

	@Override
	public List<Source> findAll() {
		return sourceDAO.findAllSources();
	}

}
