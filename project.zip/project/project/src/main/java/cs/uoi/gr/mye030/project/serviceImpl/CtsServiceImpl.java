package cs.uoi.gr.mye030.project.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cs.uoi.gr.mye030.project.dao.CtsDAO;
import cs.uoi.gr.mye030.project.model.Cts;
import cs.uoi.gr.mye030.project.service.CtsService;

@Service
public class CtsServiceImpl implements CtsService {
	
	@Autowired
	private CtsDAO ctsDAO;

	@Override
	public Cts findById(int id) {
		return ctsDAO.findCtsById(id);
	}

	@Override
	public List<Cts> findAll() {
		return ctsDAO.findAllCtss();
	}

}
