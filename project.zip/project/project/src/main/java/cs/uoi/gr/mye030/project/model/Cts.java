package cs.uoi.gr.mye030.project.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ctss")
public class Cts {
	
	@Id
	@Column(name="CTS_ID")
	private int ctsID;
    
	@Column(name="CTS_Code")
	private String ctsCode;
	
	@Column(name="CTS_Name")
	private String ctsName;
	
	@Column(name="CTS_Full_Descriptor")
	private String ctsFullDescriptor;
	
	
	public Cts() {
		
	}

	public Cts(int ctsID, String ctsCode, String ctsName, String ctsFullDescriptor) {
		super();
		this.ctsID = ctsID;
		this.ctsCode = ctsCode;
		this.ctsName = ctsName;
		this.ctsFullDescriptor = ctsFullDescriptor;
	}

	public int getCtsID() {
		return ctsID;
	}

	public void setCtsID(int ctsID) {
		this.ctsID = ctsID;
	}

	public String getCtsCode() {
		return ctsCode;
	}

	public void setCtsCode(String ctsCode) {
		this.ctsCode = ctsCode;
	}

	public String getCtsName() {
		return ctsName;
	}

	public void setCtsName(String ctsName) {
		this.ctsName = ctsName;
	}

	public String getCtsFullDescriptor() {
		return ctsFullDescriptor;
	}

	public void setCtsFullDescriptor(String ctsFullDescriptor) {
		this.ctsFullDescriptor = ctsFullDescriptor;
	}

	@Override
	public String toString() {
		return "Cts [ctsID=" + ctsID + ", ctsCode=" + ctsCode + ", ctsName=" + ctsName + ", ctsFullDescriptor="
				+ ctsFullDescriptor + "]";
	}
	
}
