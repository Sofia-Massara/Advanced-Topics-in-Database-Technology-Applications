package cs.uoi.gr.mye030.project.service;

import java.util.List;
import cs.uoi.gr.mye030.project.model.Indicator;

public interface IndicatorService {
	
	public Indicator findById(int id);
    
    public List<Indicator> findAll();

}
