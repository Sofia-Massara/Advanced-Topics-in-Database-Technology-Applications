package cs.uoi.gr.mye030.project.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="sources")
public class Source {
	
	@Id
	@Column(name="Source_ID")
	private int sourceID;
    
	@Column(name="Source_Value")
	private String sourceValue;
	
	public Source() {
		
	}

	public Source(int sourceID, String sourceValue) {
		super();
		this.sourceID = sourceID;
		this.sourceValue = sourceValue;
	}

	public int getSourceID() {
		return sourceID;
	}

	public void setSourceID(int sourceID) {
		this.sourceID = sourceID;
	}

	public String getSourceValue() {
		return sourceValue;
	}

	public void setSourceValue(String sourceValue) {
		this.sourceValue = sourceValue;
	}

	@Override
	public String toString() {
		return "Source [sourceID=" + sourceID + ", sourceValue=" + sourceValue + "]";
	}
	
}
