package cs.uoi.gr.mye030.project.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import cs.uoi.gr.mye030.project.model.Unit;

@Repository
public interface UnitDAO extends JpaRepository<Unit,Integer>{

	@Query("select u from Unit u where u.unitID = ?1")
    public Unit findUnitById(int id);
    
    @Query("select u from Unit u")
    public List<Unit> findAllUnits();
}
