package cs.uoi.gr.mye030.project.model;

import java.util.List;

public class ChartForm {
	
	private List<String> country;
    private String dataType;
    private List<Integer> years;
    private String chartType;
    
    public ChartForm() {
    	
    }

	public ChartForm(List<String> country, String dataType, List<Integer> years, String chartType) {
		super();
		this.country = country;
		this.dataType = dataType;
		this.years = years;
		this.chartType = chartType;
	}

	public List<String> getCountry() {
		return country;
	}

	public void setCountry(List<String> country) {
		this.country = country;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public List<Integer> getYears() {
		return years;
	}

	public void setYears(List<Integer> years) {
		this.years = years;
	}

	public String getChartType() {
		return chartType;
	}

	public void setChartType(String chartType) {
		this.chartType = chartType;
	}

	@Override
	public String toString() {
		return "ChartForm [country=" + country + ", dataType=" + dataType + ", years=" + years + ", chartType="
				+ chartType + "]";
	}
    
}
