package cs.uoi.gr.mye030.project.etl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DBBackupExtractor {
	
	public static void main(String[] args) {
        String dbName = "mye030_db";
        String dbUser = "root";
        String dbPassword = "root";
        String backupPath = "C:\\Tools\\Eclipse_Workspace\\project\\project\\src\\main\\resources\\sql_scripts\\Backup.sql";

        try {
            exportDatabase(dbName, dbUser, dbPassword, backupPath);
            System.out.println("Database backup successful.");
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void exportDatabase(String dbName, String dbUser, String dbPassword, String backupPath)
            throws IOException, InterruptedException {
        List<String> command = new ArrayList<>();
        command.add("C:\\Tools\\MySQL\\bin\\mysqldump");
        command.add("--databases");
        command.add(dbName);
        command.add("--user=" + dbUser);
        command.add("--password=" + dbPassword);
        command.add("--result-file=" + backupPath);

        ProcessBuilder processBuilder = new ProcessBuilder(command);
        processBuilder.redirectErrorStream(true);

        Process process = processBuilder.start();
        int exitCode = process.waitFor();

        if (exitCode != 0) {
            throw new RuntimeException("Failed to export database. Exit code: " + exitCode);
        }
    }

}
