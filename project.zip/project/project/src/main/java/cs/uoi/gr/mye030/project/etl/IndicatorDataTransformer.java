package cs.uoi.gr.mye030.project.etl;

import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

public class IndicatorDataTransformer {
	
	public static void main(String[] args) {
		String[] filePaths = {"src/main/resources/data/",
							"src/main/resources/tf_data/"};
		
        String[] csvFiles = {"Land_Cover_Accounts.csv", 
        					"Annual_Surface_Temperature_Change.csv", 
        					"Climate-related_Disasters_Frequency.csv",
        					"Forest_and_Carbon.csv"};
        
        // Transform the data
        transformIndicatorData(csvFiles, filePaths, "Tf_Indicator_Data.csv", 4);	// Indicator
        transformIndicatorData(csvFiles, filePaths, "Tf_Unit_Data.csv", 5);			// Unit
        transformIndicatorData(csvFiles, filePaths, "Tf_Source_Data.csv", 6);		// Source
        transformCTSData(csvFiles, filePaths, "Tf_Cts_Data.csv");					// CTS
        
	}
	
	// Method to add unique strings to the list
    public static void addUnique(List<String> list, String str) {
        Set<String> set = new HashSet<>(list);
        if (!set.contains(str)) {
            list.add(str);
        }
    }
	
    // Transform Indicator, Unit & Source Data
	private static void transformIndicatorData(String[] csvFiles, String[] filePaths, String outputFile, int index) {
		List<String> stringList = new ArrayList<>();
		int counter = 1;
		BufferedWriter bw;
		try {
			bw = new BufferedWriter(new FileWriter(filePaths[1]+outputFile));
			bw.write("Id, Value\n");
			for(String csvFile : csvFiles) {
				CSVReader reader = new CSVReader(new FileReader(filePaths[0]+csvFile));	// Open the file for reading
				reader.readNext();	// Read the header-first line
				String[] columns;
				String indicator = "";
				while((columns = reader.readNext()) != null) {
					indicator = columns[index];	// Reading element
			        addUnique(stringList, indicator);	// Adding strings to the list
				}
				
		        reader.close();
			}
			for (String ind : stringList) {
	            bw.write(counter + "," + "\"" + ind + "\"" + "\n");
	        	counter++;
			}
	        bw.close();
	        System.out.println("\nData transformed successfully!");
		} catch (IOException e) {
			e.printStackTrace();
		} catch (CsvValidationException e) {
			e.printStackTrace();
		}	
	}
	
	// Transform CTS Data
	private static void transformCTSData(String[] csvFiles, String[] filePaths, String outputFile) {
		List<String> stringList = new ArrayList<>();
		BufferedWriter bw;
		CSVReader reader;
		String[] list, columns;
		String indicator, code, name, desc;
		int counter = 1;
		try {
			bw = new BufferedWriter(new FileWriter(filePaths[1]+outputFile));
			bw.write("Id, CTS_Code, CTS_Name, CTS_Full_Descriptor\n");
			for(String csvFile : csvFiles) {
				reader = new CSVReader(new FileReader(filePaths[0]+csvFile));	// Open the file for reading
				reader.readNext();	// Read the header-first line
				while((columns = reader.readNext()) != null) {
					code = columns[7];
					name = columns[8];
					desc = columns[9];
					indicator = code+"-"+name+"-"+desc;
			        addUnique(stringList, indicator);	// Adding strings to the list
				}
		        reader.close();
			}
			for (String ind : stringList) {
				list = ind.split("-");
				if(list.length < 3) {
					bw.write(counter + ",,,");
				}
				else {
					bw.write(counter + "," + "\"" + list[0] + "\"" + "," + "\"" + list[1] + "\""+ "," + "\"" + list[2] + "\""+ "\n");
				}
	        	counter++;
			}
	        bw.close();
	        System.out.println("\nData transformed successfully!");
		} catch (IOException e) {
			e.printStackTrace();
		} catch (CsvValidationException e) {
			e.printStackTrace();
		}	
	}

}
