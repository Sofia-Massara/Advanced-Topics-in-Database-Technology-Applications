package cs.uoi.gr.mye030.project.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import cs.uoi.gr.mye030.project.model.Cts;

@Repository
public interface CtsDAO extends JpaRepository<Cts,Integer>{
	
	@Query("select c from Cts c where c.ctsID = ?1")
    public Cts findCtsById(int id);
    
    @Query("select c from Cts c")
    public List<Cts> findAllCtss();

}
