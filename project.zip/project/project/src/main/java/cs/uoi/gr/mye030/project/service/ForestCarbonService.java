package cs.uoi.gr.mye030.project.service;

import java.util.List;
import cs.uoi.gr.mye030.project.model.ForestCarbonRecord;

public interface ForestCarbonService {
	
	List<ForestCarbonRecord> findByCountryID(int countryID);
	
	List<Integer> findAllYears();
    
    List<Object[]> findMeanValueByCountry(int countryID);

    List<Object[]> findMaxCarbonByCountry(int countryID);
    
    List<Object[]> findAverageValueByContinent();
    
    List<Object[]> findAverageValueBetweenYearsByCountryId(int countryId, int year1, int year2);

}
