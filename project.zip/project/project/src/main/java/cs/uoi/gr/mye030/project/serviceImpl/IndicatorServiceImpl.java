package cs.uoi.gr.mye030.project.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cs.uoi.gr.mye030.project.dao.IndicatorDAO;
import cs.uoi.gr.mye030.project.model.Indicator;
import cs.uoi.gr.mye030.project.service.IndicatorService;

@Service
public class IndicatorServiceImpl implements IndicatorService {
	
	@Autowired
	private IndicatorDAO indicatorDAO;

	@Override
	public Indicator findById(int id) {
		return indicatorDAO.findIndicatorById(id);
	}

	@Override
	public List<Indicator> findAll() {
		return indicatorDAO.findAllIndicators();
	}

}
