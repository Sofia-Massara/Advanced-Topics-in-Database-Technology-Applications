package cs.uoi.gr.mye030.project.etl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CountryDataTransformer {
	
	public static void main(String[] args) {
		String inputCsvFile = "src/main/resources/data/Countries.csv";
		String outputCSVFile = "src/main/resources/tf_data/Tf_Countries_Data.csv";
		String columns = "CountryID,";
		String line;
		int countryID = 0;
		
		System.out.println("Transforming country data...");
		
		List<String> lines = new ArrayList<>();
		// Read and modify original lines
        try (BufferedReader br = new BufferedReader(new FileReader(inputCsvFile))) {
        	columns += br.readLine();
            while ((line = br.readLine()) != null) {
            	countryID++;
                lines.add(countryID+","+line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        // Write Data to a new file which is ready to be imported in the db
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(outputCSVFile))) {
        	bw.write(columns);
        	bw.newLine();
            for (String processedLine : lines) {
                bw.write(processedLine);
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Country data transformation complete!");
    }

}
