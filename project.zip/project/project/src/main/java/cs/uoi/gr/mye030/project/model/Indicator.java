package cs.uoi.gr.mye030.project.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="indicators")
public class Indicator {
	
	@Id
	@Column(name="Indicator_ID")
	private int indicatorID;
    
	@Column(name="Indicator_Value")
	private String indicatorValue;
	
	public Indicator() {
		
	}

	public Indicator(int indicatorID, String indicatorValue) {
		super();
		this.indicatorID = indicatorID;
		this.indicatorValue = indicatorValue;
	}

	public int getIndicatorID() {
		return indicatorID;
	}

	public void setIndicatorID(int indicatorID) {
		this.indicatorID = indicatorID;
	}

	public String getIndicatorValue() {
		return indicatorValue;
	}

	public void setIndicatorValue(String indicatorValue) {
		this.indicatorValue = indicatorValue;
	}

	@Override
	public String toString() {
		return "Indicator [indicatorID=" + indicatorID + ", indicatorValue=" + indicatorValue + "]";
	}
	
}