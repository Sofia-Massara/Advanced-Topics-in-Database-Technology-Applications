package cs.uoi.gr.mye030.project.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import cs.uoi.gr.mye030.project.model.Source;

@Repository
public interface SourceDAO extends JpaRepository<Source,Integer>{
	
	@Query("select s from Source s where s.sourceID = ?1")
    public Source findSourceById(int id);
    
    @Query("select s from Source s")
    public List<Source> findAllSources();

}
