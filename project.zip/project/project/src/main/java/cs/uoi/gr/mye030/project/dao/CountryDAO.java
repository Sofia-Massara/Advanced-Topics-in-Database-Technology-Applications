package cs.uoi.gr.mye030.project.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import cs.uoi.gr.mye030.project.model.Country;

@Repository
public interface CountryDAO extends JpaRepository<Country,Integer>{
	
	@Query("SELECT c FROM Country c")
    List<Country> findAllCountries();
	
	@Query("SELECT c.displayName FROM Country c")
    List<String> findAllCountryNames();
    
    @Query("SELECT c FROM Country c WHERE c.countryID = ?1")
    Country findCountryById(int id);
    
    @Query("SELECT c.displayName FROM Country c WHERE c.countryID = ?1")
    String findCountryNameById(int id);
    
    @Query("SELECT c.countryID FROM Country c WHERE c.displayName = ?1")
    int findCountryIdByName(String displayName);
    
}
