package cs.uoi.gr.mye030.project.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import cs.uoi.gr.mye030.project.model.ForestCarbonRecord;

@Repository
public interface ForestCarbonDAO extends JpaRepository<ForestCarbonRecord,Integer>{
	
	// Find all climate disasters records for a specific country
    @Query("SELECT fcr FROM ForestCarbonRecord fcr WHERE fcr.countryID = ?1")
    List<ForestCarbonRecord> findByCountryID(int countryID);
    
    @Query("SELECT Distinct(fcr.year) FROM ForestCarbonRecord fcr")
    List<Integer> findAllYears();
    
    // Calculate the mean value of Forest Carbon records for a specific country for each year
    @Query("SELECT year, AVG(fcr.value) FROM ForestCarbonRecord fcr WHERE fcr.countryID = ?1 GROUP BY Year")
    List<Object[]> findMeanValueByCountry(int countryID);

    // Find all climate disasters records for a specific country for each year
    @Query("SELECT year, MAX(fcr.value) FROM ForestCarbonRecord fcr WHERE fcr.countryID = ?1 GROUP BY Year")
    List<Object[]> findMaxCarbonByCountry(int countryID);
    
    // Calculate the average forest carbon value weighted by population for each country grouped by continent
    @Query("SELECT c.continent, AVG(fcr.value * c.population) / AVG(c.population) " +
           "FROM ForestCarbonRecord fcr " +
           "JOIN Country c ON fcr.countryID = c.countryID " +
           "GROUP BY c.continent")
    List<Object[]> findAvgForestCarbonByPopulationGroupedByContinent();
    
    @Query("SELECT fcr.year, AVG(fcr.value) FROM ForestCarbonRecord fcr " +
	           "WHERE fcr.countryID = ?1 AND fcr.year BETWEEN ?2 AND ?3 " +
	           "GROUP BY fcr.year")
	List<Object[]> findAverageValueBetweenYearsByCountryId(int countryId, int year1, int year2);

}
