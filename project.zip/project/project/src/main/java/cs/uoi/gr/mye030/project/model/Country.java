package cs.uoi.gr.mye030.project.model;

import javax.persistence.*;

@Entity
@Table(name="countries")
public class Country {
	
	@Id
	@Column(name="Country_ID")
	private int countryID;
    
	@Column(name="ISO_2")
	private String iso2;
    
	@Column(name="ISO_3")
	private String iso3;
    
	@Column(name="ISO_Code")
	private Integer isoCode;	// Change to Wrapper class and not simple int as null values are expected
    
	@Column(name="FIPS")
	private String fips;
    
	@Column(name="Display_Name")
	private String displayName;
    
	@Column(name="Official_Name")
	private String officialName;
    
	@Column(name="Capital")
	private String capital;
    
	@Column(name="Continent")
	private String continent;
    
	@Column(name="Currency_Code")
	private String currencyCode;
    
	@Column(name="Currency_Name")
	private String currencyName;
    
	@Column(name="Phone")
	private String phone;
    
	@Column(name="Region_Code")
	private Integer regionCode;
    
	@Column(name="Region_Name")
	private String regionName;
    
	@Column(name="Sub_region_Code")
	private Integer subRegionCode;
    
	@Column(name="Sub_region_Name")
	private String subRegionName;
    
	@Column(name="Intermediate_Region_Code")
	private Integer intermediateRegionCode;
    
	@Column(name="Intermediate_Region_Name")
	private String intermediateRegionName;
    
	@Column(name="Status")
	private String status;
	
	@Column(name="Development")
	private String development;
	
	@Column(name="SIDS")
	private String sids;
	
	@Column(name="LLDC")
	private String lldc;
	
	@Column(name="LDC")
	private String ldc;
	
	@Column(name="Area")
	private Integer area;
	
	@Column(name="Population")
	private Integer population;
	
	public Country() {
		
	}

	public Country(int countryID, String iso2, String iso3, int isoCode, String fips, String displayName,
			String officialName, String capital, String continent, String currencyCode, String currencyName,
			String phone, int regionCode, String regionName, int subRegionCode, String subRegionName,
			int intermediateRegionCode, String intermediateRegionName, String status, String development, String sids,
			String lldc, String ldc, int area, int population) {
		super();
		this.countryID = countryID;
		this.iso2 = iso2;
		this.iso3 = iso3;
		this.isoCode = isoCode;
		this.fips = fips;
		this.displayName = displayName;
		this.officialName = officialName;
		this.capital = capital;
		this.continent = continent;
		this.currencyCode = currencyCode;
		this.currencyName = currencyName;
		this.phone = phone;
		this.regionCode = regionCode;
		this.regionName = regionName;
		this.subRegionCode = subRegionCode;
		this.subRegionName = subRegionName;
		this.intermediateRegionCode = intermediateRegionCode;
		this.intermediateRegionName = intermediateRegionName;
		this.status = status;
		this.development = development;
		this.sids = sids;
		this.lldc = lldc;
		this.ldc = ldc;
		this.area = area;
		this.population = population;
	}

	public int getCountryID() {
		return countryID;
	}

	public void setCountryID(int countryID) {
		this.countryID = countryID;
	}

	public String getIso2() {
		return iso2;
	}

	public void setIso2(String iso2) {
		this.iso2 = iso2;
	}

	public String getIso3() {
		return iso3;
	}

	public void setIso3(String iso3) {
		this.iso3 = iso3;
	}

	public Integer getIsoCode() {
		return isoCode;
	}

	public void setIsoCode(int isoCode) {
		this.isoCode = isoCode;
	}

	public String getFips() {
		return fips;
	}

	public void setFips(String fips) {
		this.fips = fips;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getOfficialName() {
		return officialName;
	}

	public void setOfficialName(String officialName) {
		this.officialName = officialName;
	}

	public String getCapital() {
		return capital;
	}

	public void setCapital(String capital) {
		this.capital = capital;
	}

	public String getContinent() {
		return continent;
	}

	public void setContinent(String continent) {
		this.continent = continent;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getCurrencyName() {
		return currencyName;
	}

	public void setCurrencyName(String currencyName) {
		this.currencyName = currencyName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Integer getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(int regionCode) {
		this.regionCode = regionCode;
	}

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public Integer getSubRegionCode() {
		return subRegionCode;
	}

	public void setSubRegionCode(int subRegionCode) {
		this.subRegionCode = subRegionCode;
	}

	public String getSubRegionName() {
		return subRegionName;
	}

	public void setSubRegionName(String subRegionName) {
		this.subRegionName = subRegionName;
	}

	public Integer getIntermediateRegionCode() {
		return intermediateRegionCode;
	}

	public void setIntermediateRegionCode(int intermediateRegionCode) {
		this.intermediateRegionCode = intermediateRegionCode;
	}

	public String getIntermediateRegionName() {
		return intermediateRegionName;
	}

	public void setIntermediateRegionName(String intermediateRegionName) {
		this.intermediateRegionName = intermediateRegionName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDevelopment() {
		return development;
	}

	public void setDevelopment(String development) {
		this.development = development;
	}

	public String getSids() {
		return sids;
	}

	public void setSids(String sids) {
		this.sids = sids;
	}

	public String getLldc() {
		return lldc;
	}

	public void setLldc(String lldc) {
		this.lldc = lldc;
	}

	public String getLdc() {
		return ldc;
	}

	public void setLdc(String ldc) {
		this.ldc = ldc;
	}

	public Integer getArea() {
		return area;
	}

	public void setArea(int area) {
		this.area = area;
	}

	public Integer getPopulation() {
		return population;
	}

	public void setPopulation(int population) {
		this.population = population;
	}

	@Override
	public String toString() {
		return "CountryRecord [countryID=" + countryID + ", iso2=" + iso2 + ", iso3=" + iso3 + ", isoCode=" + isoCode
				+ ", fips=" + fips + ", displayName=" + displayName + ", officialName=" + officialName + ", capital="
				+ capital + ", continent=" + continent + ", currencyCode=" + currencyCode + ", currencyName="
				+ currencyName + ", phone=" + phone + ", regionCode=" + regionCode + ", regionName=" + regionName
				+ ", subRegionCode=" + subRegionCode + ", subRegionName=" + subRegionName + ", intermediateRegionCode="
				+ intermediateRegionCode + ", intermediateRegionName=" + intermediateRegionName + ", status=" + status
				+ ", development=" + development + ", sids=" + sids + ", lldc=" + lldc + ", ldc=" + ldc + ", area="
				+ area + ", population=" + population + "]";
	}
    
}
