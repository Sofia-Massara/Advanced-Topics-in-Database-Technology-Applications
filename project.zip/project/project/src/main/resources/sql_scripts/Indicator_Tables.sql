CREATE TABLE indicators (
	Indicator_ID INT AUTO_INCREMENT,
	Indicator_Value VARCHAR(255),
	PRIMARY KEY (Indicator_ID)
);

CREATE TABLE units (
	Unit_ID INT AUTO_INCREMENT,
	Unit_Value VARCHAR(150),
	PRIMARY KEY (Unit_ID)
);

CREATE TABLE sources (
	Source_ID INT AUTO_INCREMENT,
	Source_Value VARCHAR(300),
	PRIMARY KEY (Source_ID)
);

CREATE TABLE ctss (
	CTS_ID INT AUTO_INCREMENT,
	CTS_Code VARCHAR(10),
	CTS_Name VARCHAR(100),
	CTS_Full_Descriptor VARCHAR(255),
	PRIMARY KEY (CTS_ID)
);