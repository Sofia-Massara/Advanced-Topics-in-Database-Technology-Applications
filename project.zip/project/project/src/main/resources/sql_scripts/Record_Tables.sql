CREATE TABLE temperature_records (
    Record_ID INT,
    Country_ID INT,
    Indicator_ID INT,
    Unit_ID INT,
    Source_ID INT,
    CTS_ID INT,
    Year INT,
    Value FLOAT NULL,
    PRIMARY KEY (Record_ID),
    FOREIGN KEY (Country_ID) REFERENCES countries(Country_ID),
    FOREIGN KEY (Indicator_ID) REFERENCES indicators(Indicator_ID),
    FOREIGN KEY (Unit_ID) REFERENCES units(Unit_ID),
    FOREIGN KEY (Source_ID) REFERENCES sources(Source_ID),
    FOREIGN KEY (CTS_ID) REFERENCES ctss(CTS_ID)
);

CREATE TABLE climate_disasters_records (
    Record_ID INT,
    Country_ID INT,
    Indicator_ID INT,
    Unit_ID INT,
    Source_ID INT,
    CTS_ID INT,
    Year INT,
    Value INT NULL,
    PRIMARY KEY (Record_ID),
    FOREIGN KEY (Country_ID) REFERENCES countries(Country_ID),
    FOREIGN KEY (Indicator_ID) REFERENCES indicators(Indicator_ID),
    FOREIGN KEY (Unit_ID) REFERENCES units(Unit_ID),
    FOREIGN KEY (Source_ID) REFERENCES sources(Source_ID),
    FOREIGN KEY (CTS_ID) REFERENCES ctss(CTS_ID)
);

CREATE TABLE forest_carbon_records (
    Record_ID INT,
    Country_ID INT,
    Indicator_ID INT,
    Unit_ID INT,
    Source_ID INT,
    CTS_ID INT,
    Year INT,
    Value FLOAT NULL,
    PRIMARY KEY (Record_ID),
    FOREIGN KEY (Country_ID) REFERENCES countries(Country_ID),
    FOREIGN KEY (Indicator_ID) REFERENCES indicators(Indicator_ID),
    FOREIGN KEY (Unit_ID) REFERENCES units(Unit_ID),
    FOREIGN KEY (Source_ID) REFERENCES sources(Source_ID),
    FOREIGN KEY (CTS_ID) REFERENCES ctss(CTS_ID)
);

CREATE TABLE land_cover_records (
    Record_ID INT,
    Country_ID INT,
    Indicator_ID INT,
    Unit_ID INT,
    Source_ID INT,
    CTS_ID INT,
    Climate_Influence VARCHAR(50),
    Year INT,
    Value FLOAT NULL,
    PRIMARY KEY (Record_ID),
    FOREIGN KEY (Country_ID) REFERENCES countries(Country_ID),
    FOREIGN KEY (Indicator_ID) REFERENCES indicators(Indicator_ID),
    FOREIGN KEY (Unit_ID) REFERENCES units(Unit_ID),
    FOREIGN KEY (Source_ID) REFERENCES sources(Source_ID),
    FOREIGN KEY (CTS_ID) REFERENCES ctss(CTS_ID)
);
