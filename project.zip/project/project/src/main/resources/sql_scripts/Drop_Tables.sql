DROP TABLE IF EXISTS temperature_records;

DROP TABLE IF EXISTS climate_disasters_records;

DROP TABLE IF EXISTS forest_carbon_records;

DROP TABLE IF EXISTS land_cover_records;

DROP TABLE IF EXISTS indicators;

DROP TABLE IF EXISTS units;

DROP TABLE IF EXISTS sources;

DROP TABLE IF EXISTS ctss;

DROP TABLE IF EXISTS countries;